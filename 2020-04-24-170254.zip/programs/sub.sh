x=120
y=17
sub=` expr $x -  $y `
echo $sub


a=120
b=60
c=`expr $a / $b`
echo $c

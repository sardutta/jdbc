declare -a arname=('Unix' 'Red hat' 'Suse')
echo ${arname[$1]} 


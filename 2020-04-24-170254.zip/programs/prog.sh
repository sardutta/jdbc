Num=123
echo  ` expr  $Num + 3`


Date=`date`
echo "Date is $Date"
Users=`who | wc -l`
echo "Logged in Users :$Users"
UP=`date ;uptime`
echo "uptime is $UP"


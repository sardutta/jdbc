echo "select Department"
echo -e "1. Technical \t 2. Developing
echo "Select your choice [1 or 2]
read depart
if test  $depart -eq 1
then
  echo "You had selected technical as your department"
 else
   if test $depart -eq 2
then
   echo "you have selected developing as your department"
else
echo "No valid Department found"
 fi
fi


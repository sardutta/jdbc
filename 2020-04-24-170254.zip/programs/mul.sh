a=12;b=32
res=`expr $a \* $b `
echo $res


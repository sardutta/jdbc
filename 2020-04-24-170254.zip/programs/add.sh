a=1
b=2
sum=` expr $a + $b `
echo $sum 


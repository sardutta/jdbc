 if cat $1
 then
echo -e "\n\n File $1, found and successfully  echoed "
fi

